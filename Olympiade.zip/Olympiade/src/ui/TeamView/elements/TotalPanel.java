package ui.TeamView.elements;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * H�lt die Summe der Teamattribute
 * @author Katy
 *
 */
public class TotalPanel extends JPanel{
	
	private JLabel totalLabel;
	private JLabel totalVarLabel;
	
	public TotalPanel(){
		this.setBackground(Color.GRAY);

		this.setPreferredSize(new Dimension(200,30));
		initTotalPanel();
	}

	public void initTotalPanel(){
		totalLabel = new JLabel("Total:");
		totalVarLabel = new JLabel("dummy"); //TODO aus DB
		totalVarLabel.setPreferredSize(new Dimension(93,20));
		totalVarLabel.setHorizontalAlignment(JLabel.RIGHT);
		
		totalLabel.setPreferredSize(new Dimension(93,20));
		this.add(totalLabel);
		this.add(totalVarLabel);
	}
}
