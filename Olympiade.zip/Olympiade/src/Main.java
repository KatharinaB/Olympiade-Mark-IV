
import ui.MainFrame;

/**
 * 
 * @author Katy
 *
 */
public class Main {
	
	private static MainFrame mainFrame;
	
	
	public static void main(String[] args) {
		
		mainFrame = new MainFrame(1680,1050);
	}

}
